package BLL;

public class ProdutoBLL {
    
    protected int codigo;
    protected String nome;
    protected int quantidade;
    protected float preco;
    protected boolean ativo;
    
    
}
