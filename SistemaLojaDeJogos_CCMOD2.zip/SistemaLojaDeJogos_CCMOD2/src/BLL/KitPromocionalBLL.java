/*
* TORNAR ESTA CLASSE ENTIDADE NO BANCO DE DADOS
*/
package BLL;

public class KitPromocionalBLL {
    
}
