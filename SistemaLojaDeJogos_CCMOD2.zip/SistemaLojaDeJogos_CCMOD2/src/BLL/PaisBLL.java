package BLL;

public class PaisBLL {
    
    private int codigo;
    private String paisPt;
    private String paisEn;

    /**
     * @return the codigo
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * @param codigo the codigo to set
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    /**
     * @return the paisPt
     */
    public String getPaisPt() {
        return paisPt;
    }

    /**
     * @param paisPt the paisPt to set
     */
    public void setPaisPt(String paisPt) {
        this.paisPt = paisPt;
    }

    /**
     * @return the paisEn
     */
    public String getPaisEn() {
        return paisEn;
    }

    /**
     * @param paisEn the paisEn to set
     */
    public void setPaisEn(String paisEn) {
        this.paisEn = paisEn;
    }
    
}
